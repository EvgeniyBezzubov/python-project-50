### Hexlet tests and linter status:
[![Actions Status](https://github.com/EvgeniyBezzubov/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/EvgeniyBezzubov/python-project-50/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/fb91c8e607a35f4cc2f6/maintainability)](https://codeclimate.com/github/EvgeniyBezzubov/python-project-50/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/fb91c8e607a35f4cc2f6/test_coverage)](https://codeclimate.com/github/EvgeniyBezzubov/python-project-50/test_coverage)